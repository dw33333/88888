<template>
  <div class="ui-main clear">
            <div class="con_box">
                <div class="help-con">
                    <div class="help-head">
                        1 您可以通过以下方式提款
                    </div>
                    <div class="help-main">
                        <p>1、会员登陆后点选”提款”或在用户中心点击”提现”。</p><p>2、输入资金密码，确认提款人姓名与本人填写资料相符。</p><p>3、填写取款金额。</p><p>4、确认提款银行帐号与本人填写资料相符。</p><p>5、选择出款银行卡:</p><p>&nbsp; &nbsp;-绑定中国工商银行(优先)、中国农业银行、北京银行、交通银行、中国银行、中国建设银行、中国光大银行、兴业银行、中国民生银行总行、招商银行、中信银行、广东发展银行、中国邮政、深圳发展银行、上海浦东发展银行。</p>
                    </div>
                    <div class="help-head">
                        2 取款注意事项
                    </div>
                    <div class="help-main">
                        <p>1、最低取款为￥100人民币，每日(早上1点到次日2点)取款上限为￥50万人民币,不限取款次数. </p><p>2、金钻彩娱乐保留权利审核会员账户，若有效下注金额未达"每次存款额度"的取款流水要求,则无法提款成功,最低取款流水要求为存款金额的30%流水,如果参与活动,则需要满足活动流水要求才能出款。</p><p>3、本公司如发现有诈骗集团或其它非法组织进入本公司洗钱，本公司风控部门审核后有权拒绝出款。</p><p style="color:red;font-size:large;">注：会员当日流水达到充值金额30%未达到50%，当日出款上限10W;当日流水充值金额50%未达到80%，当日出款上限20W，流水达到充值金额的100%，可提当日最大提款金额50W</p><p>【例1】1月1日当下存入1000元；1月2日存入3000元，则有效投注额必须为(1000 3000)*30%=1200元流水以上才可出款，。</p><p>【例2】若有效投注已达最低存款金额的出款流水要求， 但参加了一个需要流水3000元的活动则需要达到3000元的流水要求才能出款.</p><p>&nbsp;</p><p>**如有任何疑问，欢迎您随时联系24小时在线客服！</p><p>**请注意**各游戏未接受/取消注单，不纳入有效投注计算。彩票游戏，计算有效投注金额。</p>
                    </div>
                </div>
            </div>
        </div>
</template>

<script>
export default {

}
</script>

<style>
.ui-main {
    background: #ededed;
    margin-left: 213px;
    min-height: 900px;
    min-width: 1600px;
}
.con_box {
    background: #ededed;
    float: left;
    width: 100%;
}
.help-con {
    padding: 30px;
    text-align: left;
}
.help-head {
    border-top: 1px solid #ccc;
    background: #d3d3d3;
    line-height: 30px;
    padding: 0 10px;
    font-size: 16px;
}
.help-main {
    border-left: 1px solid #ccc;
    border-right: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    padding: 10px;
} 
.help-main p {
    padding: 5px;
    margin: 10px;
}
p {
    font-size: 14px;
    color: #666;
}
</style>
