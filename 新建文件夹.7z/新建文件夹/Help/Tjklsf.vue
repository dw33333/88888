<template>
  <table border="0" cellpadding="0" cellspacing="0" align="center" style="padding:30px;">
        <tbody>
        <tr>
            <td class="table_td2"><table  border="0" cellspacing="0" cellpadding="0" align="center">
              <tbody><tr>
                <td class="title_td">&nbsp;&nbsp;&nbsp;&nbsp;天津快乐十分游戏规则 </td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><ol class="no_style">
                  <li>每期天津快乐十分开奖球数共八粒。每粒球除了总和玩法，其它都有单独的投注页面。天津快乐十分每天开84期，每期间隔10分钟。投注时间为8分钟，等待开奖时间为2分钟，北京时间（GMT+8）每天白天从上午09：00开到晚上23：00。</li>
                </ol></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td class="bold_black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1、第一球 ~ 第八球</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">第一球~第八球：</span>
                    <ul>
                <li class="no_style">第一球、第二球、第三球、第四球、第五球、第六球、第七球、第八球：指下注的每一球特码与开出之号码其开奖顺序及开奖号码相同，视为中奖，如第一球开出号码 8，下注第一球为 8 者视为中奖，其余情形视为不中奖。</li>
                    </ul>
                  </li>
                  <li><span class="red">两面：</span>
<ul>
                <li class="no_style">指单、双；大、小、尾大、尾小。</li>
                <li class="no_style">单、双：号码为双数叫双，如8、16；号码为单数叫单，如19、5。</li>
                <li class="no_style">大、小：开出之号码大于或等于11为大，小于或等于10为小。</li>
                <li class="no_style">尾大、尾小：开出之尾数大于或等于5为尾大，小于或等于4为尾小。</li>
                <li class="no_style">每一个号码为一投注组合，假如投注号码为开奖号码并在所投的球位置，视为中奖，其余情形视为不中奖。</li>
                    </ul>
                  </li>
                  <li><span class="red">中发白：</span>
<ul>
                <li class="no_style">中：开出之号码为01、02、03、04、05、06、07</li>
                <li class="no_style">发：开出之号码为08、09、10、11、12、13、14</li>
                <li class="no_style">白：开出之号码为15、16、17、18、19、20</li>
                    </ul>
                  </li>
                  <li><span class="red">方位：</span>
<ul>
                <li class="no_style">东：开出之号码为01、05、09、13、17</li>
                <li class="no_style">南：开出之号码为02、06、10、14、18</li>
                <li class="no_style">西：开出之号码为03、07、11、15、19</li>
                <li class="no_style">北：开出之号码为04、08、12、16、20</li>
                    </ul>
                  </li>
                </ul>
                  
                  </td>
              </tr>
              <tr>
                <td class="bold_black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2、总和</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">总和单双：</span>
<ul class="no_style">
                <li>所有8个开奖号码的数字总和值是单数为总和单，如数字总和值是31、51；所有8个开奖号码的数字总和值是双数为总和双，如数字总和是42、80；假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖。</li>
                    </ul>
                  </li>
                  <li><span class="red">总和大小：</span>
<ul class="no_style">
                <li>所有8个开奖号码的数字总和值85到132为总大；所有8个开奖号码的数字总和值36到83为总分小；所有8个开奖号码的数字总和值为84打和；如开奖号码为01、20、02、08、17、09、11，数字总和是68，则总分小。假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖，打和不计算结果。</li>
                    </ul>
                  </li>
                  <li><span class="red">总尾大小：</span>
<ul class="no_style">
                <li>所有8个开奖号码的数字总和数值的个位数大于或等于5为总尾大，小于或等于4为总尾小；假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
              <tr>
                <td class="bold_black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3、龙虎</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">龙：</span>
<ul class="no_style">
                <li>开出之号码第一球的中奖号码大于第八球的中奖号码。如 第一球开出14 第八球开出09；第一球开出17 第八球开出08；第一球开出05 第八球开出01...中奖为龙。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">虎：</span>
<ul class="no_style">
                <li>开出之号码第一球的中奖号码小于第八球的中奖号码。如 第一球开出14 第八球开出16；第一球开出13 第八球开出18；第一球开出05 第八球开出08...中奖为虎。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
            </tbody></table></td>
        </tr>
        <tr>
            <td class="table_td3">&nbsp;
                </td>
        </tr>
    </tbody></table>
</template>

<script>
export default {

}
</script>

<style>

</style>
