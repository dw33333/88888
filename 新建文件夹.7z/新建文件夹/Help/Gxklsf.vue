<template>
  <div class="rule_from02" style="padding:30px;">
				  <p> 广西福利彩票快乐十分经国家财政部批准，由中国福利彩票发行管理中心在广西区内发行，由广西福利彩票发行中心承销。
					该游戏的投注时间、开奖时间和开奖号码与广西福利彩票快乐十分完全同步，北京时间（GMT+8）每天上午9:00开到晚上21:30，每十五分钟开一次奖，每天开奖50期。 <br>
				  </p><table style="width: 94%;">
					<tbody>
					  <tr>
						<th width="25%" valign="top" bgcolor="#AFAFE4" align="center" class="subtitle2"> 游戏项目 </th>
						<th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 开奖时间 </th>
						<th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 每日期数 </th>
						<th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 开奖频率 </th>
					  </tr>
					  <tr>
						<td valign="middle" align="center" bgcolor="#FFF7F0" class="point"> 广西快乐十分 </td>
						<td bgcolor="#FFF7F0" class="point" align="center"> 09:00-21:30(北京时间) </td>
						<td bgcolor="#FFF7F0" class="point" align="center"> 001-050 </td>
						<td bgcolor="#FFF7F0" class="point" align="center"> 每15分钟 </td>
					  </tr>
					</tbody>
				  </table>
				  <p></p>
				  <br>
				  <p> 本公司广西快乐十分具体游戏规则如下︰ <br>
					假设快乐十分开奖结果为1、2、3、4、5，那么正码是1、2、3、4，特码是5。（每个位数在开奖时，从1 ~ 21中摇出一个结果）选号玩法。 </p>
				  <br>
				  <h2 style="margin-bottom:5px">单双大小</h2>
				  <ol>
					<li>根据正码一~正码四及特码开出的球号判断胜负</li>
					<li>大小：开出号码01~10为小，11~20为大，21为和</li>
					<li>单双：开出号码21为和</li>
				  </ol>
				  <h2 style="margin-bottom:5px">尾大、小</h2>
				  <ol>
					<li>开出之特码尾数大于或等于5为尾大，小于或等于4为尾小，出21为和</li>
				  </ol>
				  <h2 style="margin-bottom:5px">合单双</h2>
				  <ol>
					<li>以号特码个位和十位数字之合来判断胜负，如01、12、16为合单；02、11、20为合双；出21为和</li>
				  </ol>
				  <h2 style="margin-bottom:5px">福禄寿喜</h2>
				  <ol>
					<li>依号码顺序将21除外的20个号码分为四种类（如下），再以四种类下注</li>
					<li>福：01、02、03、04、05</li>
					<li>禄：06、07、08、09、10</li>
					<li>寿：11、12、13、14、15</li>
					<li>喜：16、17、18、19、20</li>
					<li>若当期号码在相对应的球位落在下注四种类范围内，视为中奖</li>
				  </ol>
				  <h2 style="margin-bottom:5px">色波</h2>
				  <ol>
					<li>红：1、4、7、10、13、16、19</li>
					<li>蓝：2、5、8、11、14、17、20</li>
					<li>绿：3、6、9、12、15、18、21</li>
					<li>若当期号码在相对应的球位落在下注三种类范围内，视为中奖</li>
				  </ol>
				  <h2 style="margin-bottom:5px">合数单双</h2>
				  <ol>
					<li>合单：指开出球号的个位数加上十位数之和为“单数”，如1、14、18</li>
					<li>合双：指开出球号的个位数加上十位数之和为“双数”，如11、15、19</li>
				  </ol>
				  <h2 style="margin-bottom:5px">总和</h2>
				  <ol>
					<li>总大小：数字总和值56~95为总大，数字总和值15~54为总小，所有5个开奖号码的总和值为55打和</li>
					<li>总单双：数字总和值是双数为总和双，数字总和值是单双为总和单</li>
					<li>总尾大小：所有5个开奖号码的数字总和数值的个位数大于或等于5为总尾大，小于或等于4为总尾小假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖</li>
				  </ol>
				  <h2 style="margin-bottom:5px">龙虎</h2>
				  <ol>
					<li>龙：第一球开奖号码大于第五球开奖号码，如第一球开出10，第五球开出7</li>
					<li>虎：第一球开奖号码小于第五球开奖号码，如第一球开出3，第五球开出7</li>
				  </ol>
				  <!--rule_from02 end--> 
				</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
