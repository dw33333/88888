<template>
    <div class="ui-main clear">
            <div class="con_box">
                <div class="help-con">
                            <div class="help-head">
                                1 银行卡入款
                            </div>
                            <div class="help-main">
                                <p>我们有支持银联转帐，在充值页面点”银行卡入款(公司入款)”，进入公司入款页面即可查看 11娱乐提供的入款银行,选择相应银行进行入款。</p><p>目前提供中国工商银行、中国建设银行、中国农业银行三间银行可选择，同行互转存款到帐时间约为三到十分钟，跨行划款需依据银行划款作业时间为基准，我们将于确认到帐后立刻为您游戏帐户充值。</p><p>银行卡入款单次最高存款:200000</p>
                            </div>
                            <div class="help-head">
                                2 线上支付
                            </div>
                            <div class="help-main">
                                <p>会员登入后点选"在线支付"，进入线上第三方支付。 </p><p>选择入款额度，提交后进入第三方支付平台,完成入款后会在3-5分钟内自动把额度充入您的游戏账户中。</p><p>在线支付单次最高存款:40000</p><p>支持借记卡：中国民生银行总行,中国工商银行,中国建设银行,兴业银行,中国光大银行,深圳发展银行,中国邮政,华夏银行,上海浦东发展银行,中国银行,上海银行,交通银行,广东发展银行,北京银行,中信银行,深圳平安银行,中国农业银行,招商银行。</p><p>确认充值金额后﹐将请您确认您的支付订单无误，并建议您记录您的支付订单号后，确认送出，并耐心等待载入网络银行页面﹐传输中已将您账户数据加密﹐请耐心等待。</p><p>进入网络银行页面﹐请确实填写您银行账号信息﹐支付成功﹐额度将在5分钟内系统处理完成，立即加入您的彩票会员账户(由于银行原因,第三方支付有时会有一定延迟,如果在5-30分钟内还未到账,请联系在线客服,提供相应资料进行处理)。</p>
                            </div>
                            <div class="help-head">
                                3 存款需知
                            </div>
                            <div class="help-main">
                                <p>单笔最低存款为￥100人民币，银行入款单笔最高存款200000,第三方支付单次最高存款为40000。</p><p>未开通网银的会员，请您去相应的银行柜台办理或通过ATM机进行入款。 </p><p>如有任何问题，请您联系24小时在线客服。</p>
                            </div>
                </div>
            </div>
        </div>
</template>

<script>
export default {
    name:'Deposit',
    data () {
        return {
            
        }
    }
}
</script>

<style>
.ui-main{
    background: #ededed;
    margin-left: 213px;
    min-height: 900px;
    min-width: 1600px;
    text-align: left;
}
.con_box {
    background: #ededed;
    float: left;
    width: 100%;
}
.help-con {
    padding: 30px;
}
.help-head {
    border-top: 1px solid #ccc;
    background: #d3d3d3;
    line-height: 30px;
    padding: 0 10px;
    font-size: 16px;
}
.help-main {
    border-left: 1px solid #ccc;
    border-right: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
}
.help-main {
    padding: 10px;
}
.help-main p {
    padding: 5px;
    font-size: 14px;
    color: #666;
    margin: 8px 0;
}
</style>
