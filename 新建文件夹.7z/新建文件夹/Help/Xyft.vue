<template>
  <div class="rule_from02">幸运飞艇（Lucky-Air-Ship）是一种起源于F1赛艇的彩票游戏，是马耳他共和国瓦莱塔福利联合委员会发行的一款高频彩，游戏由十架飞艇作为开奖号码，五<br>分钟为一个开奖周期。 <strong>幸运飞艇开奖时间：</strong>
				  <table style="width: 94%;">
					<tbody><tr>
					  <th width="25%" valign="top" bgcolor="#AFAFE4" align="center" class="subtitle2"> 游戏项目 </th>
					  <th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 开奖时间 </th>
					  <th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 每日期数 </th>
					  <th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 开奖频率 </th>
					</tr>
					<tr>
					  <td valign="middle" align="center" bgcolor="#FFF7F0" class="point"> 幸运飞艇 </td>
					  <td bgcolor="#FFF7F0" class="point" align="center"> 13:09—04:04(北京时间) </td>
					  <td bgcolor="#FFF7F0" class="point" align="center"> 001-180 </td>
					  <td bgcolor="#FFF7F0" class="point" align="center"> 每5分钟 </td>
					</tr>
				  </tbody></table>
				  <br>
				  <p> 本公司幸运飞艇具体游戏规则如下︰ </p>
				  <br>
				  <h2>两面盘（冠军~第十名）</h2>
				  <dd>
					<ul>
					  <li> 大小∶开出之号码大於或等於6为大，小於或等於5为小。 </li>
					  <li> 单双∶开出之号码为双数叫双，如4、8；号码为单数叫单，如5、9。 </li>
					  <li> 冠军 龙/虎∶"第一名"之船号大於"第十名"之船号视为「龙」中奖、反之小於视为「虎」中奖，其馀情况视为不中奖。 </li>
					  <li> 亚军 龙/虎∶"第二名"之船号大於"第九名"之船号视为「龙」中奖、反之小於视为「虎」中奖，其馀情况视为不中奖。 </li>
					  <li> 季军 龙/虎∶"第三名"之船号大於"第八名"之船号视为「龙」中奖、反之小於视为「虎」中奖，其馀情况视为不中奖。 </li>
					  <li> 第四名 龙/虎∶"第四名"之船号大於"第七名"之船号视为「龙」中奖、反之小於视为「虎」中奖，其馀情况视为不中奖。 </li>
					  <li> 第五名 龙/虎∶"第五名"之船号大於"第六名"之船号视为「龙」中奖、反之小於视为「虎」中奖，其馀情况视为不中奖。 </li>
					</ul>
				  </dd>
				  <h2>两面盘（冠亚和）: "冠军船号 + 亚军船号 = 冠亚和"</h2>
				  <dd>
					<ul>
					  <li> 冠亚和大小∶以冠军船号和亚军船号之和大小来判断胜负，"冠亚和"大於11为大，小於或等於11为小。假如投注组合符合中奖结果，视为中奖，其馀情形视为不中奖。 </li>
					  <li> 冠亚和单双∶以冠军船号和亚军船号之和单双来判断胜负，"冠亚和"为双数叫双，为单数叫单。  假如投注组合符合中奖结果，视为中奖，其馀情形视为不中奖。 </li>
					  <li> 冠亚和指定: 以指定冠军船号和亚军船号之和来判断胜负；冠亚船号总和可能出现结果为3~19，投中对应"冠亚和指定"数字视为中奖，其馀情形视为不中奖 </li>
					</ul>
				  </dd>
				  <h2>冠军~第十名船号指定:</h2>
				  <dd>
					<ul>
					  <li> 冠军~第十名船号指定: 每一个船号为一投注组合，开奖结果"投注船号"对应所投名次视为中奖，其馀情形视为不中奖。 </li>
					</ul>
				  </dd>
				</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
