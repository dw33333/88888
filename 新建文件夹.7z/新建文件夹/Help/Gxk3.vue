<template>
  <div class="rule_from02">
				  <p> 该游戏的投注时间、开奖时间和开奖号码与“广西快三”完全同步，北京时间（GMT+8）每天白天从上午09:30开到晚上22:30，每10分钟开一次奖,每天开奖78期。 <br>
				  </p><table style="width: 94%;">
					<tbody>
					  <tr>
						<th width="25%" valign="top" bgcolor="#AFAFE4" align="center" class="subtitle2"> 游戏项目 </th>
						<th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 开奖时间 </th>
						<th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 每日期数 </th>
						<th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 开奖频率 </th>
					  </tr>
					  <tr>
						<td valign="middle" align="center" bgcolor="#FFF7F0" class="point"> 广西快三 </td>
						<td bgcolor="#FFF7F0" class="point" align="center"> 09:30-22:30(北京时间) </td>
						<td bgcolor="#FFF7F0" class="point" align="center"> 001-078 </td>
						<td bgcolor="#FFF7F0" class="point" align="center"> 每10分钟 </td>
					  </tr>
					</tbody>
				  </table>
				  <p></p>
				  <br>
				  <p> 本公司广西快三具体游戏规则如下︰ </p>
				  <br>
				  <h2 style="margin-bottom:5px">骰宝，博彩者可在下列各瓣下注</h2>
				  <ol>
					<li>小：三粒骰子之点数总和由4点至10点</li>
					<li>大：三粒骰子之点数总和由11点至17点；注：若三粒骰子平面点数相同，通吃「大」、「小」各注</li>
					<li>三军/鱼虾蟹：任何一粒骰子出现选定之平面点数</li>
					<li>围骰：三粒骰子平面与选定点数相同</li>
					<li>全骰：在一点至六点内，三粒骰子平面点数相同</li>
					<li>点数：由4点至17点，三粒骰子平面点数之总和</li>
					<li>长牌：任两粒骰子之平面点数</li>
					<li>短牌：选定两粒骰子之平面点数</li>
				  </ol>
				</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
