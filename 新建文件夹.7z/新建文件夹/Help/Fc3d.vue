<template>
  <table  border="0" cellpadding="0" cellspacing="0" align="center" style="padding:30px;">
        <tbody><tr>
        </tr>
        <tr>
            <td class="table_td2"><table  border="0" cellspacing="0" cellpadding="0" align="center">
              <tbody><tr>
                <td class="title_td">&nbsp;&nbsp;&nbsp;&nbsp;福彩3D玩法规则 </td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><ol class="no_style">
                  <li>该游戏的投注时间、开奖时间和开奖号码与福彩3D完全同步，北京时间（GMT+8）每天白天从上午8：00到晚上20：00每天开奖 1 期。 

</li>
                </ol></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td class="bold_black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1、第一球 ~ 第三球</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">第一球~第三球：</span>
<ul>
                <li class="no_style">第一球、第二球、第三球：指下注的每一球特码与开出之号码其开奖顺序及开奖号码相同，视为中奖，如第一球开出号码 8，下注第一球为 8 者视为中奖，其余情形视为不中奖。</li>
                    </ul>
                  </li>
                  <li><span class="red">单双大小</span>
<ul>
                <li class="no_style">根据相应单项投注第一球 ~ 第三球开出的球号，判断胜负。</li>
                    </ul>
                  </li>
                  <li><span class="red">大小：</span>
<ul>
                <li class="no_style">根据相应单项投注的第一球 ~ 第三球开出的球号大于或等于 5 为特码大，小于或等于 4 为特码小。</li>
                    </ul>
                  </li>
                  <li><span class="red">单双：</span>
<ul>
                <li class="no_style">根据相应单项投注的第一球 ~ 第三球开出的球号为双数则为特码双，如 2、6；球号为单数则为特码单，如 1、3。</li>
                    </ul>
                  </li>
                </ul>
                  
                  </td>
              </tr>
              <tr>
                <td class="bold_black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2、总和</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">大小：</span>
<ul class="no_style">
                <li>根据相应单项投注的第一球 ~ 第三球开出的球号数字总和值大于或等于 14 为总和大，小于或等于 13 为总和小。</li>
                    </ul>
                  </li>
                  <li><span class="red">单双：</span>
<ul class="no_style">
                <li>根据相应单项投注的第一球 ~ 第三球开出的球号数字总和值是双数为总和双，数字总和值是单数为总和单。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
              <tr>
                <td class="bold_black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3、三连特殊玩法： 豹子 &gt; 顺子 &gt; 对子 &gt; 半顺 &gt; 杂六</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">豹子：</span>
<ul class="no_style">
                <li>开奖号码的百位十位个位数字都相同。如中奖号码为：222、666、888...开奖号码的百位十位个位数字相同，则投注三连豹子者视为中奖，其它视为不中奖。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">顺子：</span>
<ul class="no_style">
                <li>开奖号码的百位十位个位数字都相连，不分顺序（数字9、0、1相连）。如中奖号码为：123、901、321、798...开奖号码的百位十位个位数字相连，则投注三连顺子者视为中奖，其它视为不中奖。 </li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">对子：</span>
<ul class="no_style">
                <li>开奖号码的百位十位个位任意两位数字相同（不包括豹子）。如中奖号码为：001，288、696...开奖号码的百位十位个位有两位数字相同，则投注三连对子者视为中奖，其它视为不中奖。如果开奖号码为三连豹子，则三连对子视为不中奖。 </li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">半顺：</span>
<ul class="no_style">
                <li>开奖号码的百位十位个位任意两位数字相连，不分顺序（不包括顺子、对子）。如中奖号码为：125、540、390、160...开奖号码的百位十位个位有两位数字相连，则投注三连半顺者视为中奖，其它视为不中奖。如果开奖号码为三连顺子、三连对子，则三连半顺视为不中奖。如开奖号码为：123、901、556、233...视为不中奖。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">杂六：</span>
<ul class="no_style">
                <li>不包括豹子、对子、顺子、半顺的所有开奖号码。如开奖号码为：157、268...开奖号码位数之间无关联性，则投注三连杂六者视为中奖，其它视为不中奖。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
            
              <tr>
                <td class="bold_black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4、龙虎和特殊玩法： 龙 &gt; 虎 &gt; 和 （0为最小，9为最大）</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">龙：</span>
<ul class="no_style">
                <li>开奖第一球（百位）的号码 大于 第三球（个位）的号码。如：第一球开出 6，第三球开出 2、第一球开出 8，第三球开出 6、第一球开出 5，第三球开出 1...开奖为龙，投注龙者视为中奖，其它视为不中奖。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">虎：</span>
<ul class="no_style">
                <li>开奖第一球（百位）的号码 小于 第三球（个位）的号码。如：第一球开出 2，第三球开出 6、第一球开出 6，第三球开出 8、第一球开出 1，第三球开出 5...开奖为虎，投注虎者视为中奖，其它视为不中奖。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">和：</span>
<ul class="no_style">
                <li>开奖第一球（百位）的号码 等于 第三球（个位）的号码。如：2X2、6X6、8X8...开奖为和，投注和者视为中奖，其它视为不中奖。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
			   <tr>
                <td class="bold_black">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5、跨度</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td><ul>
                  <li><span class="red">跨度：</span>
<ul class="no_style">
                <li>以开奖三个号码的最大差距(跨度)，作为中奖的依据。会员可以选择 0 ~ 9 的任一跨度。 。</li>
                    </ul>
                  </li>
                </ul></td>
              </tr>
            </tbody></table></td>
        </tr>
        <tr>
            <td class="table_td3">&nbsp;
                </td>
        </tr>
    </tbody></table>
</template>

<script>
export default {

}
</script>

<style>

</style>
