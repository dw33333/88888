<template>
    <div class="rule_from02" style="padding:30px;">

                        <strong>甘肃北京（快3）开奖时间：</strong>

                        <table style="width: 94%;">

                            <tbody>
                                <tr>

                                    <th width="25%" valign="top" bgcolor="#AFAFE4" align="center" class="subtitle2">

                                        游戏项目

                                    </th>

                                    <th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2">

                                        开奖时间

                                    </th>

                                    <th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2">

                                        每日期数

                                    </th>

                                    <th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2">

                                        开奖频率

                                    </th>

                                </tr>

                                <tr>

                                    <td valign="middle" align="center" bgcolor="#FFF7F0" class="point">

                                        甘肃（快3）

                                    </td>

                                    <td bgcolor="#FFF7F0" class="point" align="center">

                                        09:10—23:50(北京时间)

                                    </td>

                                    <td bgcolor="#FFF7F0" class="point" align="center">

                                        001-089

                                    </td>

                                    <td bgcolor="#FFF7F0" class="point" align="center">

                                        每10分钟

                                    </td>

                                </tr>

                            </tbody>
                        </table>

                        <br>

                        <p>

                            本公甘肃（快3）具体游戏规则如下︰

                        </p>

                        <br>

                        <h2>甘肃（快3）</h2>
                        <dt>

                            ◎双面

                        </dt>

                        <dd>

                            <ul>
                                <li>
                                    以全部开出的三个号码、加起来的总和来判定。
                                </li>
                                <li>

                                    大小：三个开奖号码总和值11~17 为大；总和值4~10 为小；三个号码相同，则不算中奖。

                                </li>
                            </ul>
                        </dd>
                        <dt>

                            ◎三军

                        </dt>
                        <dd>
                            <ul>
                                <li>

                                    三个开奖号码其中一个与所选号码相同时、即为中奖。举例：如开奖号码为1、1、3，则投注三军1或三军3皆视为中奖。




                                </li>
                            </ul>
                        </dd>
                        <dt>◎围骰/全骰</dt>
                        <dd>
                            <ul>
                                <li>

                                    围骰：开奖号码三字同号、且与所选择的围骰组合相符时，即为中奖。

                                </li>

                                <li>

                                    全骰：全选围骰组合、开奖号码三字同号，即为中奖。

                                </li>
                            </ul>
                        </dd>
                        <dt>◎点数</dt>
                        <dd>
                            <ul>
                                <li>

                                    开奖号码总和值为4、5、6、7、8、9、10、11、12、13、14、15、16、17 时，即为中奖；若开出3、18，则不算中奖。举例：如开奖号码为1、2、3、总和值为6、则投注「6」即为中奖。

                                </li>
                            </ul>
                        </dd>
                        <dt>◎长牌</dt>
                        <dd>
                            <ul>
                                <li>

                                    任选一长牌组合、当开奖结果任2码与所选组合相同时，即为中奖。举例：如开奖号码为1、2、3、则投注长牌12、长牌23、长牌13皆视为中奖。

                                </li>
                            </ul>
                        </dd>
                        <dt>◎短牌</dt>
                        <dd>
                            <ul>
                                <li>

                                    开奖号码任两字同号、且与所选择的短牌组合相符时，即为中奖。举例：如开奖号码为1、1、3、则投注短牌1、1，即为中奖。

                                </li>

                            </ul>

                        </dd>
                    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
