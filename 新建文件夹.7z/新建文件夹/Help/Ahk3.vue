<template>
  <div id="ah_k3" class="ruleset" style="padding:30px;">
					<div class="content">
						<br>
						<ol>
							<li>「安徽快3」由中国福利彩票发行管理中心组织销售、安徽省福利彩票发行中心承销。 </li>
							<li>开奖时间：每日早上8点40分至晚上10点00分；每日共开奖80期，每10分钟开奖1次。 </li>
							<li>每期开出3个号码、每个号码范围01~06 。 </li>
							<li>
								如开奖时间异动以中国福利彩票管理中心公告为准。
								<br>
								<strong>官方网站</strong>：<a target="_blank" href="http://www.ahfc.gov.cn/index.shtml">http://www.ahfc.gov.cn/index.shtml</a>
								<br> 即时开奖：
								<a target="_blank" href="http://www.shishicai.cn/ahk3/touzhu/">http://www.shishicai.cn/ahk3/touzhu/</a>
							</li>
						</ol>
						<br>

						<h2 class="iconl"><span>玩法</span></h2>

						<p style="background-color: #afafe4;">◎和值</p>

						<ul>
							<li>
								以全部开出的三个号码、加起来的总和来判定。
								<br>

								<ul>
									<li>大小：三个开奖号码总和值11~17 为大；总和值4~10 为小；三个号码相同，则不算中奖。</li>
									<li>单双：三个开奖号码总和5、7、9、11、13、15、17为单；4、6、8、10、12、14、16为双；若三个号码相同、则不算中奖。</li>
								</ul>
							</li>
						</ul>

						<ul>
							<li>
								开奖号码总和值为3、4、5、6、7、8、9、10、11、12、13、14、15、16、17 、18时，即为中奖；
								<br>

								<ul>
									<li>举例：如开奖号码为1、2、3、总和值为6、则投注「6」即为中奖。</li>
								</ul>
							</li>
						</ul>
						<p style="background-color: #afafe4;">◎独胆</p>

						<ul>
							<li>
								三个开奖号码其中一个与所选号码相同时、即为中奖。
								<br>

								<ul>
									<li>举例：如开奖号码为1、1、3，则投注独胆1或独胆3皆视为中奖。 </li>
									<li>备注：不论当局指定点数出现几次，仅派彩一次(不翻倍)。</li>
								</ul>
							</li>
						</ul>

						<p style="background-color: #afafe4;">◎豹子</p>

						<ul>
							<li>豹子：开奖号码三字同号、且与所选择的豹子组合相符时，即为中奖。 </li>
							<li>任意豹子：任意豹子组合、开奖号码三字同号，即为中奖。</li>
						</ul>

						<p style="background-color: #afafe4;">◎两连</p>

						<ul>
							<li>
								任选一长牌组合、当开奖结果任2码与所选组合相同时，即为中奖。
								<br>

								<ul>
									<li>举例：如开奖号码为1、2、3、则投注两连12、两连23、两连13皆视为中奖。</li>
								</ul>
							</li>
						</ul>

						<p style="background-color: #afafe4;">◎对子</p>

						<ul style=" margin-bottom:0px;">
							<li>
								开奖号码任两字同号、且与所选择的对子组合相符时，即为中奖。
								<br>

								<ul>
									<li>举例：如开奖号码为1、1、3、则投注对子1、1，即为中奖。</li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
