<template>
  <div class="rule_from02">
				  <p> 「广东11选5」是由国家体育总局发行，体育彩票管理中心承销，北京时间（GMT+8）每日早上9点至晚上11点；每日共开奖 84期、每 10 分钟开奖 1 次。以下所有投注皆含本金。 <br>
				  </p><table style="width: 94%;">
					<tbody>
					  <tr>
						<th width="25%" valign="top" bgcolor="#AFAFE4" align="center" class="subtitle2"> 游戏项目 </th>
						<th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 开奖时间 </th>
						<th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 每日期数 </th>
						<th width="25%" bgcolor="#AFAFE4" align="center" class="subtitle2"> 开奖频率 </th>
					  </tr>
					  <tr>
						<td valign="middle" align="center" bgcolor="#FFF7F0" class="point"> 广东11选5 </td>
						<td bgcolor="#FFF7F0" class="point" align="center"> 09:00-23:00(北京时间) </td>
						<td bgcolor="#FFF7F0" class="point" align="center"> 001-084 </td>
						<td bgcolor="#FFF7F0" class="point" align="center"> 每10分钟 </td>
					  </tr>
					</tbody>
				  </table>
				  <p></p>
				  <br>
				  <p> 本公司广东11选5具体游戏规则如下︰ </p>
				  <br>
				  <h2 style="margin-bottom:5px">【单码】- 指第一球、第二球、第三球、第四球、第五球出现的顺序与号码为派彩依据</h2>
				  <ol>
					<li>单号：如现场滚球第一个开奖号码为10号，投注第一球为10号则视为中奖，其它号码视为不中奖 大小：开出的号码大于或等于6为大，小于或等于5为小，开出11为和 (不计算输赢)</li>
					<li>单双：号码为双数叫双，如2、8；号码为单数叫单，如5、9；开出11为和 (不计算输赢)</li>
				  </ol>
				  <h2 style="margin-bottom:5px">【总和】-以全部开出的5个号码，加起来的总和来判定</h2>
				  <ol>
					<li>总和大小: 所有开奖号码数字加总值大于30为和大；总和值小于30为和小；若总和值等于30为和 (不计算输赢)</li>
					<li>总和单双: 所有开奖号码数字加总值为单数叫和单，如11、31；加总值为双数叫和双，如42、30</li>
					<li>总和尾数大小: 所有开奖号码数字加总值的尾数，大于或等于5为尾大，小于或等于4为尾小</li>
				  </ol>
				  <h2 style="margin-bottom:5px">【龙虎】</h2>
				  <ol>
					<li>龙：第一球开奖号码大于第五球开奖号码，如第一球开出10，第五球开出7</li>
					<li>虎：第一球开奖号码小于第五球开奖号码，如第一球开出3，第五球开出7</li>
				  </ol>
				  <h2 style="margin-bottom:5px">选号- 选号玩法是由1~11号中，选出1~5个号码为一投注组合来进行投注</h2>
				  <ol>
					<li>一中一: 投注1个号码与当期开奖的5个号码中任1个号码相同，视为中奖</li>
					<li>任选二: 投注2个号码与当期开奖的5个号码中任2个号码相同(顺序不限)，视为中奖</li>
					<li>任选三: 投注3个号码与当期开奖的5个号码中任3个号码相同(顺序不限)，视为中奖</li>
					<li>任选四: 投注4个号码与当期开奖的5个号码中任4个号码相同(顺序不限)，视为中奖</li>
					<li>任选五: 投注5个号码与当期开奖的5个号码中5个号码相同(顺序不限)，视为中奖</li>
					<li>任选六: 投注6个号码中任5个号码与当期开奖的5个号码相同(顺序不限)，视为中奖</li>
					<li>任选七: 投注7个号码中任5个号码与当期开奖的5个号码相同(顺序不限)，视为中奖</li>
					<li>任选八: 投注8个号码中任5个号码与当期开奖的5个号码相同(顺序不限)，视为中奖</li>
					<li>组选前二: 投注的2个号码与当期顺序开出的5个号码中的前2个号码相同，视为中奖</li>
					<li>组选前三: 投注的3个号码与当期顺序开出的5个号码中的前3个号码相同，视为中奖</li>
					<li>直选前二: 投注的2个号码与当期顺序开出的5个号码中的前2个号码相同且顺序一致，视为中奖</li>
					<li>直选前三: 投注的3个号码与当期顺序开出的5个号码中的前3个号码相同且顺序一致，视为中奖</li>
				  </ol>
				</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
